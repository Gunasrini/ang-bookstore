import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private _httpClient: HttpClient) { }


  saveBooks(books: any[]): Observable<any> {
    return this._httpClient.post("https://boostore-f445e-default-rtdb.firebaseio.com/data.json", books);
  }


  getBooks() {
    return this._httpClient.get("https://boostore-f445e-default-rtdb.firebaseio.com/data.json");
  }


}
